<?php

// http://php.net/manual/en/function.password-verify.php



$username = 'DonaldTrump';
$password = '1234';

$login = $username . $password;
// here retrieve the hash from a database by looking upo the login
$hash = password_hash($login, PASSWORD_DEFAULT);
echo "$login  $hash<br>";


if (password_verify($login, $hash)) {
    echo 'Password is valid!<br>';
} else {
    echo 'Invalid password.<br>';
}

$login = $username . $password ;
// here retrieve the hash from a database by looking upo the login
$login .= '5';
echo "$login  $hash<br>";
if (password_verify($login, $hash)) {
    echo 'Password is valid!<br>';
} else {
    echo 'Invalid password.<br>';
}



// http://php.net/manual/en/function.password-get-info.php
var_dump(password_get_info($hash));


?>