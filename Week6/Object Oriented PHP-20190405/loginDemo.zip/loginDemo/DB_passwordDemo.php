<?php
require_once('MySQLDB.php');

$host = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'passworddemo';

// create a new database object and connect to server
$db = new MySQL($host, $dbUser, $dbPass, $dbName );
  
//  drop the database and then create it again
//$db->dropDatabase();
$db->createDatabase();

// drop  the table
$db->selectDatabase();
$sql = "drop table if exists password";
$result = $db->query($sql);
    


// create the table
$sql = "create table if not exists password ( login varchar(50),  hash varchar(210) )";
//  execute the sql 
$result = $db->query($sql);


// insert some rows

$username = 'DonaldTrump';
$password = '1234';
$login = $username . $password;
$hash = password_hash($login, PASSWORD_DEFAULT);

$sql = "insert into password  values ( '$username', '$hash' )";
echo "$sql<br>";
$result = $db->query($sql);
//var_dump($result);
echo '<br>';


$username = 'MickeyMouse';
$password = 'abcs';
$login = $username . $password;
$hash = password_hash($login, PASSWORD_DEFAULT);


// view the table
$sql = "insert into password  values ( '$username', '$hash' )";
echo "$sql<br>";
$result = $db->query($sql);
//var_dump($result);
echo '<br>';









$sql = "Select * from password";
// execute the sql
$result = $db->query($sql);
$rows = $result->size();
print "number of rows:  $rows<br>";

while ($myrow = $result->fetch())
{
    $login = $myrow['login'];
    $hash =  $myrow['hash'];
    echo  "$login   $hash<br>";
} 



// find and verify a valid password
$username = 'DonaldTrump';
$password = '1234';
$login = $username . $password;
$hashFromLogin = password_hash($login, PASSWORD_DEFAULT);
echo "hash from login $hashFromLogin<br>";

$sql = "Select * from password  where login='$username'";
echo "$sql<br>";
// execute the sql
$result = $db->query($sql);
$rows = $result->size();
$row = $result->fetch();
echo "number of rows: $rows<br><br>";
$hashFromDatabase =  $row['hash'];
//var_dump($rows);
echo '<br><br>';
echo "hash from database$hashFromDatabase<br><br>";

if (password_verify($login, $hashFromDatabase)) {
    echo 'Password is valid!<br>';
} else {
    echo 'Invalid password.<br>';
}


// find and verify a invalid password
$username = 'DonaldTrump';
$password = '123';
$login = $username . $password;
$hashFromLogin = password_hash($login, PASSWORD_DEFAULT);
echo "hash from login $hashFromLogin<br>";

$sql = "Select * from password  where login='$username'";
echo "$sql<br>";
// execute the sql
$result = $db->query($sql);
$rows = $result->size();
$row = $result->fetch();
echo "number of rows: $rows<br><br>";
$hashFromDatabase =  $row['hash'];
//var_dump($rows);
echo '<br><br>';
echo "hash from database$hashFromDatabase<br><br>";

if (password_verify($login, $hashFromDatabase)) {
    echo 'Password is valid!<br>';
} else {
    echo 'Invalid password.<br>';
}



