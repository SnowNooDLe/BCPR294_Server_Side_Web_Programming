<html>

<a href="build.php">Build The Database</a>
<br /><br />

<a href="Ex1.php">Example 1 - Display all items, sorted by item name</a>
<br /><br />

<a href="Ex2.php">Example 2 - Display all items in order of price descending</a>
<br /><br />

<a href="Ex3.php">Example 3 - Items with all fields displayed</a>
<br /><br />

<a href="Ex4.php">Example 4 - Items that need to be re-ordered</a>
<br /><br />

<a href="Ex5.php">Example 5 - Insert a new item</a>
<br /><br />

<a href="Ex6.php">Example 6 - Total value of all items</a>
<br /><br />

<a href="Ex7.php">Example 7 - Total value of all items - another way</a>

</html>